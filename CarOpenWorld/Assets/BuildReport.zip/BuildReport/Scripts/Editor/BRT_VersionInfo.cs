//This asset was uploaded by https://unityassetcollection.com

namespace BuildReportTool
{
	public static class Info
	{
		public const string ReadableVersion = "Build Report Tool v3.9.4";
	}
}