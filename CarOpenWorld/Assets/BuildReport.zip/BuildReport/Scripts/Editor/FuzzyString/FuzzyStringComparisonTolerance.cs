﻿//This asset was uploaded by https://unityassetcollection.com

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FuzzyString
{
	public enum FuzzyStringComparisonTolerance
	{
		Strong,

		Normal,

		Weak,

		Manual
	}
}
